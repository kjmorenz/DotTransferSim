import newmakefigpulse as m 

filepath = "C:/Users/Karen/Dropbox (WilsonLab)/WilsonLab Team Folder/Data/Karen/DotTransferSim/RawData/Basic/A Real Test/A Real Test.g2.run/"
file = "g2"
savename = "test"

m.makepulsedfig(filepath, file, savename)